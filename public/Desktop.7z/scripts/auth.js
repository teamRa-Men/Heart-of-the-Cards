const signupForm = document.querySelector('#signup-form');
signupForm.addEventListener('submit', (e) => {
	e.preventDefalut();

	const email = signupForm['signup-email'].value;
	const password = signupForm['signup-password'].value;

	auth.createUserWithEmailAndPassword(email, password).then(cred => {
		console.log(cred.user);
		const modal = document.querySelector('#cards-signup');
		M.Modal.getInstance(modal).close();
		signupForm.reset();
	})
	})

const logout = document.querySelector('#logout');
logout.addEventListener('click', (e) => {
	e.preventDefalut();
	auth.signOut().then(() => {
		console.log('user signed out');
	});
})